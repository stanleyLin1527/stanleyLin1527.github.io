#version 330 core

in vec3 vNormal;
in vec3 vWorldPos;
in vec4 vFragPosLightSpace;

out vec4 FragColor;

uniform vec3 uBaseColor;

uniform vec3 uLightPos;
uniform vec3 uLightDirection;
uniform int uLightType; // 0 = Directional Light, 1 = Point Light

uniform vec3 uLightColor;
uniform float uLightIntensity;
uniform vec3 uViewPos;

uniform sampler2D uShadowMap;
uniform float uShadowStrength;
uniform bool uUseShadow;

uniform bool uUseToon;
uniform int uToonLevels;
uniform float uToonBlend;
uniform float uToonSpecularThreshold;

float CalculateShadow(vec4 fragPosLightSpace, vec3 normal, vec3 lightDir)
{
    if (!uUseShadow)
    {
        return 0.0;
    }

    // Clip space -> NDC�C
    vec3 projCoords = fragPosLightSpace.xyz / fragPosLightSpace.w;

    // NDC [-1, 1] -> texture coordinate [0, 1]�C
    projCoords = projCoords * 0.5 + 0.5;

    // �W�X shadow map �d��N���⳱�v�C
    if (projCoords.z > 1.0 ||
        projCoords.x < 0.0 || projCoords.x > 1.0 ||
        projCoords.y < 0.0 || projCoords.y > 1.0)
    {
        return 0.0;
    }

    // ��� shadow acne�C
    float bias;

    if (uLightType == 1)
    {
        bias = max(0.002 * (1.0 - dot(normal, lightDir)), 0.0005);
    }
    else
    {
        bias = max(0.005 * (1.0 - dot(normal, lightDir)), 0.001);
    }

    float currentDepth = projCoords.z;
    float shadow = 0.0;

    // PCF�G�� 3x3 �P�� texel �������A�����v��t�y�L�X�M�C
    vec2 texelSize = 1.0 / textureSize(uShadowMap, 0);

    for (int x = -1; x <= 1; ++x)
    {
        for (int y = -1; y <= 1; ++y)
        {
            float closestDepth = texture(
                uShadowMap,
                projCoords.xy + vec2(x, y) * texelSize
            ).r;

            shadow += currentDepth - bias > closestDepth ? 1.0 : 0.0;
        }
    }

    return shadow / 9.0;
}

float QuantizeDiffuse(float diffuseValue)
{
    float levels = max(float(uToonLevels), 2.0);
    return floor(diffuseValue * levels) / (levels - 1.0);
}

void main()
{
    vec3 normal = normalize(vNormal);

    vec3 lightDir;

    if (uLightType == 0)
    {
        // Directional Light
        // uLightDirection ���ܥ��Ӯg��V�A��Phong shading�n���Ofragment���Vlight����V�A�ҥH�[�t���C
        lightDir = normalize(-uLightDirection);
    }
    else
    {
        // Point Light
        lightDir = normalize(uLightPos - vWorldPos);
    }

    // Diffuse
    float diffuse = max(dot(normal, lightDir), 0.0);
    if (uUseToon)
    {
        float toonDiffuse = QuantizeDiffuse(diffuse);
        diffuse = mix(diffuse, toonDiffuse, uToonBlend);
    }
    vec3 diffuseTerm = diffuse * uLightColor * uLightIntensity;

    // Ambient
    float ambientStrength = 0.35;
    vec3 ambient = ambientStrength * uLightColor;

    // Specular
    vec3 viewDir = normalize(uViewPos - vWorldPos);
    vec3 reflectDir = reflect(-lightDir, normal);

    float specularStrength = 0.45;
    float shininess = 32.0;
    float specular = pow(max(dot(viewDir, reflectDir), 0.0), shininess);
    if (uUseToon)
    {
        float toonSpecular = specular > uToonSpecularThreshold ? 1.0 : 0.0;
        specular = mix(specular, toonSpecular, uToonBlend);
    }

    vec3 specularTerm = specularStrength * specular * uLightColor * uLightIntensity;

    float shadow = CalculateShadow(vFragPosLightSpace, normal, lightDir);

    float shadowFactor = 1.0 - shadow * uShadowStrength;

    vec3 finalColor = uBaseColor * (
        ambient +
        shadowFactor * (diffuseTerm + specularTerm)
    );

    FragColor = vec4(finalColor, 1.0);
}