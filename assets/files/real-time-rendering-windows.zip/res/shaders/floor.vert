#version 330 core

layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec3 aColor;
layout(location = 3) in vec2 aTexUV;

out vec3 vNormal;
out vec3 vWorldPos;
out vec2 vTexUV;
out vec4 vFragPosLightSpace;

uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProjection;
uniform mat4 uLightSpaceMatrix;
uniform vec4 uClipPlane;   // (0,1,0,-waterLevel) during reflection; (0,0,0,0) otherwise

void main()
{
    vec4 worldPos = uModel * vec4(aPos, 1.0);

    vWorldPos = worldPos.xyz;
    vNormal = mat3(transpose(inverse(uModel))) * aNormal;
    vTexUV = aTexUV;

    // Shadow mapping �ݭn�� light space �y�Хh�d shadow map�C
    vFragPosLightSpace = uLightSpaceMatrix * worldPos;

    gl_Position = uProjection * uView * worldPos;
    gl_ClipDistance[0] = dot(vec4(worldPos.xyz, 1.0), uClipPlane);
}