#version 330 core

in vec3 vWorldPos;
in vec3 vWorldNormal;
in vec2 vTexUV;
in vec4 vClipPos;

out vec4 FragColor;

uniform sampler2D uRefractionTex;   // sceneFBO color copy (not sceneFBO directly)
uniform sampler2D uSceneDepthTex;   // sceneFBO depth texture (GL_DEPTH24_STENCIL8)
uniform sampler2D uReflectionTex;   // reflectionFBO color (half-res)
uniform sampler2D uNormalMap;       // GL_RGB8 uncompressed (required for Toksvig rho accuracy)

uniform float uTime;
uniform vec3  uCameraPos;
uniform vec3  uLightDir;            // normalized, pointing toward light
uniform vec3  uLightColor;

uniform vec2  uNormalScrollSpeed1, uNormalScrollSpeed2;
uniform float uNormalTiling1, uNormalTiling2;

uniform vec3  uAbsorptionCoeff;     // per-channel: red attenuates fastest → blue-green at depth
uniform vec3  uDeepColor;
uniform float uMaxDepth;
uniform float uRefractionStrength;
uniform float uNear, uFar;

uniform float uNormalStrength;
uniform float uFresnelBias, uFresnelPower;

uniform float uSpecularPower;
uniform float uToksvigScale;

float LinearizeDepth(float d) {
    float z = d * 2.0 - 1.0;
    return (2.0 * uNear * uFar) / (uFar + uNear - z * (uFar - uNear));
}

void main()
{
    // Step 1: Normal map sampling — preserve raw length for Toksvig rho
    vec2 uv1 = vTexUV * uNormalTiling1 + uNormalScrollSpeed1 * uTime;
    vec2 uv2 = vTexUV * uNormalTiling2 + uNormalScrollSpeed2 * uTime;

    vec3 n1 = texture(uNormalMap, uv1).rgb * 2.0 - 1.0;
    vec3 n2 = texture(uNormalMap, uv2).rgb * 2.0 - 1.0;

    float rho = (length(n1) + length(n2)) * 0.5;   // mip-averaged length for Toksvig

    // R(n.x) → world X; G(n.y) → world Z (NOT the B channel)
    vec3 waveDistort = vec3(n1.x + n2.x, 0.0, n1.y + n2.y);
    vec3 normal = normalize(vWorldNormal + waveDistort * uNormalStrength);

    // Step 2: Screen UV + distortion
    vec2 projUV  = (vClipPos.xy / vClipPos.w) * 0.5 + 0.5;
    vec2 distort = normal.xz * uRefractionStrength;

    vec2 refrUV = clamp(projUV + distort,                       0.001, 0.999);
    vec2 reflUV = clamp(projUV + vec2(distort.x, -distort.y),   0.001, 0.999);
    // Reflection Y negated: optical reciprocity — same sign causes directional tearing.

    // Step 3: Edge bleed fix + Beer-Lambert depth
    // Cache initial depth sample to avoid redundant fetch on the common (non-bleed) path.
    float surfLinear  = LinearizeDepth(gl_FragCoord.z);
    float rawDepth    = texture(uSceneDepthTex, refrUV).r;
    float sceneLinear = LinearizeDepth(rawDepth);

    if (sceneLinear < surfLinear) {
        // Distorted UV sampled above-water geometry — fall back to undistorted UV.
        refrUV      = projUV;
        rawDepth    = texture(uSceneDepthTex, projUV).r;
        sceneLinear = LinearizeDepth(rawDepth);
    }

    float waterDepth = max(sceneLinear - surfLinear, 0.0);
    waterDepth = min(waterDepth, uMaxDepth); // cap so infinite-depth areas still show refraction

    // Physical Beer-Lambert: per-channel exponential extinction
    vec3 extinction = exp(-uAbsorptionCoeff * waterDepth / uMaxDepth);
    vec3 refraction = texture(uRefractionTex, refrUV).rgb * extinction
                    + uDeepColor * (1.0 - extinction);

    // Step 4: Reflection sampling
    vec3 reflection = texture(uReflectionTex, reflUV).rgb;

    // Step 5: Fresnel blend (Schlick approximation)
    vec3  viewDir   = normalize(uCameraPos - vWorldPos);
    float cosTheta  = max(dot(normal, viewDir), 0.0);
    float fresnel   = uFresnelBias + (1.0 - uFresnelBias) * pow(1.0 - cosTheta, uFresnelPower);
    vec3  waterColor = mix(refraction, reflection, clamp(fresnel, 0.0, 1.0));

    // Step 6: Toksvig specular anti-aliasing
    // rho < 1 at distance → smaller adjSpec → no sparkle on distant water
    float sigma2    = (1.0 - rho) / max(rho, 0.001) * uToksvigScale;
    float adjSpec   = uSpecularPower / (1.0 + uSpecularPower * sigma2);
    vec3  halfVec   = normalize(viewDir + uLightDir);
    float specAngle = max(dot(normal, halfVec), 0.0);
    vec3  specular  = uLightColor * pow(specAngle, max(adjSpec, 1.0));

    // Step 7: Output
    FragColor = vec4(waterColor + specular, 1.0);
}
