#version 330 core

layout(location = 0) in vec3  aPosition;
layout(location = 1) in float aSize;
layout(location = 2) in vec3  aColor;
layout(location = 3) in float aAlpha;

out vec3  vColor;
out float vAlpha;

uniform mat4 uView;
uniform mat4 uProjection;
uniform vec4 uClipPlane;

void main()
{
    gl_ClipDistance[0] = dot(uClipPlane, vec4(aPosition, 1.0));

    vec4  eyePos   = uView * vec4(aPosition, 1.0);
    gl_Position    = uProjection * eyePos;

    // Scale point size by view-space depth so world-space size is consistent.
    float depth    = max(-eyePos.z, 0.1);
    gl_PointSize   = clamp(aSize * 400.0 / depth, 2.0, 512.0);

    vColor = aColor;
    vAlpha = aAlpha;
}
