#version 330 core

in vec3  vColor;
in float vAlpha;

out vec4 FragColor;

void main()
{
    // gl_PointCoord is [0,1]^2; map to [-1,1] and compute radial distance.
    vec2  offset = gl_PointCoord - vec2(0.5);
    float dist   = length(offset) * 2.0;   // 0 at center, 1 at edge

    // Soft disc: bright core that fades smoothly to transparent at the rim.
    float radial = smoothstep(1.0, 0.15, dist);

    // Discard fully transparent fragments to avoid depth writes.
    float finalAlpha = vAlpha * radial;
    if (finalAlpha < 0.004)
        discard;

    FragColor = vec4(vColor, finalAlpha);
}
