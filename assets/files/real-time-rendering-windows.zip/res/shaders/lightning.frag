#version 330 core

in float vAlpha;

out vec4 FragColor;

uniform vec3  uCoreColor;
uniform float uAlphaScale;

void main()
{
    float a = vAlpha * uAlphaScale;
    if (a < 0.004) discard;
    FragColor = vec4(uCoreColor, a);
}
