#version 330 core

in vec3 vWorldPos;
in vec3 vNormal;

out vec4 FragColor;

uniform samplerCube uEnvironmentMap;
uniform vec3 uViewPos;
uniform float uEnvironmentBlend;
uniform float uReflectivity;

void main()
{
    vec3 normal = normalize(vNormal);
    vec3 viewToFrag = normalize(vWorldPos - uViewPos);
    vec3 reflectionDir = reflect(viewToFrag, normal);

    vec3 baseColor = vec3(0.8, 0.8, 0.8);
    vec3 environmentColor = texture(uEnvironmentMap, reflectionDir).rgb * uReflectivity;

    vec3 finalColor = mix(baseColor, environmentColor, uEnvironmentBlend);

    FragColor = vec4(finalColor, 1.0);
}