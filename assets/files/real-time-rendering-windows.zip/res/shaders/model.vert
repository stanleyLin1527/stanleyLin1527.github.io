#version 330 core

layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec3 aColor;
layout(location = 3) in vec2 aTexUV;

// Model matrix can't be uniform bcuz instance rendering need those matrix to be different
layout(location = 4) in vec4 iModelRow0;
layout(location = 5) in vec4 iModelRow1;
layout(location = 6) in vec4 iModelRow2;
layout(location = 7) in vec4 iModelRow3;

out vec3 vNormal;
out vec3 vWorldPos;
out vec4 vFragPosLightSpace;

uniform mat4 uView;
uniform mat4 uProjection;
uniform mat4 uLightSpaceMatrix;
uniform vec4 uClipPlane;   // (0,1,0,-waterLevel) during reflection; (0,0,0,0) otherwise

void main()
{
    mat4 model = mat4(
        iModelRow0,
        iModelRow1,
        iModelRow2,
        iModelRow3
    );

    vec4 worldPos = model * vec4(aPos, 1.0);

    vWorldPos = worldPos.xyz;
    vNormal = mat3(transpose(inverse(model))) * aNormal;

    // Shadow mapping �ݭn�� light space �y�Хh�d shadow map�C
    vFragPosLightSpace = uLightSpaceMatrix * worldPos;

    gl_Position = uProjection * uView * worldPos;
    gl_ClipDistance[0] = dot(vec4(worldPos.xyz, 1.0), uClipPlane);
}