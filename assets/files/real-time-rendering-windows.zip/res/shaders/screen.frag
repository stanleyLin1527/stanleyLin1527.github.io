#version 330 core

in vec2 vTexUV;

out vec4 FragColor;

uniform sampler2D uScene;
uniform sampler2D uPreviousScene;
uniform vec2 uTexelSize;

// 0 = None
// 1 = Sobel Edge
// 2 = Mosaic
// 3 = Motion Blur
uniform int uEffectMode;

uniform float uSobelBlend;
uniform float uSobelThreshold;

uniform float uMosaicBlockSize;
uniform float uMosaicBlend;

uniform float uMotionBlurStrength;

float Luminance(vec3 color)
{
    return dot(color, vec3(0.299, 0.587, 0.114));
}

float GetSobelEdge(vec2 uv)
{
    float tl = Luminance(texture(uScene, uv + vec2(-uTexelSize.x,  uTexelSize.y)).rgb);
    float t  = Luminance(texture(uScene, uv + vec2( 0.0,           uTexelSize.y)).rgb);
    float tr = Luminance(texture(uScene, uv + vec2( uTexelSize.x,  uTexelSize.y)).rgb);

    float l  = Luminance(texture(uScene, uv + vec2(-uTexelSize.x,  0.0)).rgb);
    float r  = Luminance(texture(uScene, uv + vec2( uTexelSize.x,  0.0)).rgb);

    float bl = Luminance(texture(uScene, uv + vec2(-uTexelSize.x, -uTexelSize.y)).rgb);
    float b  = Luminance(texture(uScene, uv + vec2( 0.0,          -uTexelSize.y)).rgb);
    float br = Luminance(texture(uScene, uv + vec2( uTexelSize.x, -uTexelSize.y)).rgb);

    float gx =
        -tl - 2.0 * l - bl +
         tr + 2.0 * r + br;

    float gy =
         tl + 2.0 * t + tr -
         bl - 2.0 * b - br;

    float edge = length(vec2(gx, gy));

    // Remove weak edges. Lower threshold keeps more edges.
    edge = smoothstep(uSobelThreshold, 1.0, edge);

    return clamp(edge, 0.0, 1.0);
}

vec3 ApplySobel(vec3 sceneColor)
{
    float edge = GetSobelEdge(vTexUV);
    return mix(sceneColor, vec3(edge), uSobelBlend);
}

vec3 ApplyMosaic(vec3 sceneColor)
{
    vec2 screenSize = 1.0 / uTexelSize;
    vec2 pixelCoord = vTexUV * screenSize;

    float blockSize = max(uMosaicBlockSize, 1.0);
    vec2 blockCoord = floor(pixelCoord / blockSize) * blockSize;
    vec2 blockCenter = blockCoord + vec2(blockSize * 0.5);
    vec2 mosaicUV = clamp(blockCenter / screenSize, vec2(0.0), vec2(1.0));

    vec3 mosaicColor = texture(uScene, mosaicUV).rgb;
    return mix(sceneColor, mosaicColor, uMosaicBlend);
}

vec3 ApplyMotionBlur(vec3 sceneColor)
{
    vec3 previousColor = texture(uPreviousScene, vTexUV).rgb;
    return mix(sceneColor, previousColor, uMotionBlurStrength);
}

void main()
{
    vec3 sceneColor = texture(uScene, vTexUV).rgb;

    if (uEffectMode == 1)
    {
        FragColor = vec4(ApplySobel(sceneColor), 1.0);
        return;
    }

    if (uEffectMode == 2)
    {
        FragColor = vec4(ApplyMosaic(sceneColor), 1.0);
        return;
    }

    if (uEffectMode == 3)
    {
        FragColor = vec4(ApplyMotionBlur(sceneColor), 1.0);
        return;
    }

    // No effect
    FragColor = vec4(sceneColor, 1.0);
}