#version 330 core

layout(location = 0) in vec3  aPosition;
layout(location = 1) in float aJitterSeed;   // 0 = anchored (no jitter)
layout(location = 2) in float aAlpha;

out float vAlpha;

uniform mat4  uView;
uniform mat4  uProjection;
uniform float uTime;
uniform float uJitterSpeed;   // structural changes per second
uniform float uJitterAmount;  // world-space displacement magnitude
uniform vec4  uClipPlane;

// Hash-based noise: unique random value in [0,1] for each (seed, time-bucket) pair.
float hashNoise(float n)
{
    return fract(sin(n) * 43758.5453);
}

void main()
{
    vec3 pos = aPosition;

    if (aJitterSeed > 0.001)
    {
        float bucket = floor(uTime * uJitterSpeed);
        pos.x += (hashNoise(aJitterSeed * 113.9 + bucket) * 2.0 - 1.0) * uJitterAmount;
        pos.y += (hashNoise(aJitterSeed * 239.7 + bucket) * 2.0 - 1.0) * uJitterAmount;
        pos.z += (hashNoise(aJitterSeed * 463.1 + bucket) * 2.0 - 1.0) * uJitterAmount;
    }

    gl_ClipDistance[0] = dot(uClipPlane, vec4(pos, 1.0));

    gl_Position = uProjection * uView * vec4(pos, 1.0);
    vAlpha = aAlpha;
}
