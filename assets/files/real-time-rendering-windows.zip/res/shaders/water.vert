#version 330 core

layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aTexUV;

out vec3 vWorldPos;
out vec3 vWorldNormal;
out vec2 vTexUV;
out vec4 vClipPos;

uniform mat4  uModel, uView, uProjection;
uniform vec4  uClipPlane;
uniform float uTime;

struct GerstnerWave {
    vec2  direction;   // normalized, XZ plane
    float amplitude;
    float steepness;
    float k;           // pre-computed: 2π / wavelength
    float omega;       // pre-computed: speed * k
};

uniform GerstnerWave uWaves[2];
uniform int uWaveCount;

void main()
{
    // All phase calculations use origWorldPos — never the displaced position.
    // Using displaced pos.xz would corrupt wave 2's phase when steepness > 0.
    vec3 origWorldPos = (uModel * vec4(aPos, 1.0)).xyz;
    vec3 displacedPos = origWorldPos;

    float derivX = 0.0, derivY = 0.0, derivZ = 0.0;

    for (int i = 0; i < uWaveCount; i++) {
        GerstnerWave w = uWaves[i];

        float phi  = w.k * dot(w.direction, origWorldPos.xz) - w.omega * uTime;
        float cosP = cos(phi);
        float sinP = sin(phi);
        float kA   = w.k * w.amplitude;

        // Gerstner displacement
        displacedPos.x += w.steepness * w.amplitude * w.direction.x * cosP;
        displacedPos.y += w.amplitude * sinP;
        displacedPos.z += w.steepness * w.amplitude * w.direction.y * cosP;

        // Partial derivative accumulation for analytical normal
        derivX += w.direction.x * kA * cosP;
        derivY += w.steepness   * kA * sinP;
        derivZ += w.direction.y * kA * cosP;
    }

    // Analytical normal (linearized Gerstner, Y-up)
    // Nx, Nz start from 0; only Ny starts from 1 (flat-surface baseline)
    vWorldNormal = normalize(vec3(-derivX, 1.0 - derivY, -derivZ));
    vWorldPos    = displacedPos;
    vTexUV       = aTexUV;
    vClipPos     = uProjection * uView * vec4(displacedPos, 1.0);
    gl_Position  = vClipPos;

    gl_ClipDistance[0] = dot(vec4(displacedPos, 1.0), uClipPlane);
}
