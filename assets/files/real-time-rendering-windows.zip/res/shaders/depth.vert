#version 330 core

layout(location = 0) in vec3 aPos;

layout(location = 4) in vec4 iModelRow0;
layout(location = 5) in vec4 iModelRow1;
layout(location = 6) in vec4 iModelRow2;
layout(location = 7) in vec4 iModelRow3;

uniform mat4 uModel;
uniform mat4 uLightSpaceMatrix;

// false�G�@�몫��A�Ҧp floor�A�ϥ� uModel�C
// true�Ginstanced model�A�ϥ� iModelRow0~3�C
uniform bool uUseInstanceModel;

void main()
{
    mat4 instanceModel = mat4(
        iModelRow0,
        iModelRow1,
        iModelRow2,
        iModelRow3
    );

    mat4 model = uUseInstanceModel ? instanceModel : uModel;

    gl_Position = uLightSpaceMatrix * model * vec4(aPos, 1.0);
}